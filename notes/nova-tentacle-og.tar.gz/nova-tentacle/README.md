# nova-tentacle (OG Ubuntu node)

Mesh: UDP 41776 ping/pong. Mail-slot: inbox/*.json -> outbox/*.result.json

Start:
  cd ~/pg/nova-tentacle
  NOVA_NODE_ID=og-ubuntu python3 bin/tentacle_node.py

Or:
  bash bin/start.sh
